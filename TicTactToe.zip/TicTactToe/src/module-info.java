/**
 * 
 */
/**
 * @author kiran
 *
 */
module TicTactToe {
	requires java.desktop;
}